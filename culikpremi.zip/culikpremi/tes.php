class September
 {

static void main()
     {
         Plane plane = new Plane();

Tower Torre1 = new Tower ();
Tower Torre2 = new Tower ();

plane.Crash(Torre1,Torre2);
    }
}
