phython telegramv1.1.py

sleep 10

python telegramv1.1.py

exit
