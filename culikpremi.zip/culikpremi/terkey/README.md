# terkey
Termux keys shortcut

# usage
$pkg install python<br>
$pkg install git<br>
$git clone https://github.com/karjok/terkey<br>
$cd terkey<br>
$python terkey.py


